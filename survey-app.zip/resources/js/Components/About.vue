<template>

    <div>
        <h1>EnqueteApp</h1>
        <p>Plataforma de criação de Enquetes</p>
        <hr>
        <span>Versão 1.0.0</span>
    </div>
    
</template>

<script>

export default {
    setup() {
        
    },
}

</script>
